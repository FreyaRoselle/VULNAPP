<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php';

$id = $_GET['id'];

$sql = "SELECT username, password FROM users WHERE id=$id";
$result = mysqli_query($conn, $sql);

$row = mysqli_fetch_assoc($result);

echo "<h2>Username: " . $row['username'] . "</h2>";
echo "<h3>Password: " . $row['password'] . "</h3>";
?>

