<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['upload'])) {
    $filename = $_FILES['file']['name'];
    $tmp = $_FILES['file']['tmp_name'];

    move_uploaded_file($tmp, "uploads/" . $filename);
    echo "<h3>File uploaded successfully!</h3>";
}
?>

<form method="POST" enctype="multipart/form-data">
<input type="file" name="file"><br><br>
<input type="submit" name="upload" value="Upload">
</form>
