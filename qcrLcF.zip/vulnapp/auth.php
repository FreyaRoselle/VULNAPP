<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['login'])) {
    $_SESSION['user'] = $_POST['username'];
    echo "<h2>Welcome " . $_SESSION['user'] . "</h2>";
}
?>

<form method="POST">
Username: <input type="text" name="username"><br><br>
<input type="submit" name="login" value="Login">
</form>
