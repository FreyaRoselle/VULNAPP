<?php
// BROKEN ACCESS CONTROL
// No authentication or authorization check

echo "<h2>Admin Panel</h2>";
echo "<p>Welcome Admin</p>";
echo "<p>Database Credentials:</p>";
echo "<ul>
        <li>DB User: root</li>
        <li>DB Password: root123</li>
      </ul>";
?>
