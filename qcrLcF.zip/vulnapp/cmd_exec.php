<?php
// COMMAND INJECTION VULNERABILITY

if (isset($_GET['cmd'])) {
    $cmd = $_GET['cmd'];
    system($cmd);
}
?>

<h2>Command Execution Page</h2>
<form method="GET">
    <input type="text" name="cmd" placeholder="Enter command">
    <input type="submit" value="Run">
</form>
