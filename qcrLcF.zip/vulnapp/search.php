<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$query = $_GET['q'];
echo "<h3>You searched for: " . $query . "</h3>";
?>

<form method="GET">
<input type="text" name="q">
<input type="submit" value="Search">
</form>
