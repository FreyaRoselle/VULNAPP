<?php
if (isset($_GET['ip'])) {
    $ip = $_GET['ip'];
    system("ping -c 4 " . $ip);
}
?>

<form method="GET">
    <input type="text" name="ip" placeholder="Enter IP">
    <input type="submit" value="Ping">
</form>
