<?php
// Backup File Information - COMMAND INJECTION

if (isset($_POST['file'])) {
    $file = $_POST['file'];

    // Intended to show backup size
    $cmd = "du -h backups/" . $file;
    $output = shell_exec($cmd);

    echo "<pre>$output</pre>";
}
?>

<h2>Backup Information</h2>
<form method="POST">
    <label>Select Backup File:</label><br>
    <input type="text" name="file" placeholder="db_backup.sql">
    <br><br>
    <input type="submit" value="Get Info">
</form>
